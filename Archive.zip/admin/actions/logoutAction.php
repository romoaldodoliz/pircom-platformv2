<?php
// Incluir helper de autenticação
require_once(__DIR__ . '/../helpers/auth.php');

// Fazer logout
logout();
?>
